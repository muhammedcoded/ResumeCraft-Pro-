# ResumeCraft Pro | Resume & CV Builder

A polished, browser-based resume builder with a personal dashboard, three ATS-conscious resume templates, live CV preview, guided writing suggestions, a resume health checklist, job-description keyword comparison, local document management, and print-to-PDF export.

**Built using:** HTML5, CSS3 and vanilla JavaScript. No framework, account, API key, Python, or Node.js is needed to use the website.

## Features

- **Dashboard:** See saved resumes and their checklist scores.
- **Resume editor:** Add contact information, summary, skills, work history, education, projects and certifications.
- **Three layouts:** Classic ATS, Modern Professional, Compact, each with an adjustable accent color.
- **Live preview:** Watch changes appear in the printable resume as you type.
- **ATS readiness:** An explainable 100-point completeness checklist. It checks important resume fields, measurable achievements, and a simple layout.
- **Job description comparison:** Paste a vacancy and see keywords found in your CV and potential gaps.
- **Writing assistant:** Turn truthful descriptions of responsibilities, tools and measurable outcomes into three editable bullet drafts, without an external AI service.
- **Multiple resumes:** Create, edit, duplicate and delete several variations.
- **PDF export:** Print from the browser and select **Save as PDF**.
- **Privacy and portability:** Resumes stay in browser Local Storage. Save and restore JSON backups.
- **Responsive dashboard:** Designed for desktops, tablets and phones.

## Run in Visual Studio Code

1. On this GitHub repository, click **Code**, then **Download ZIP**.
2. Extract the ZIP.
3. Open **Visual Studio Code** and choose **File > Open Folder**.
4. Select the `resumecraft-pro` folder.
5. Open the `index.html` file in your web browser, or double-click `index.html` in the project folder.

**That's it.** The website needs no installation, package manager, API token, or server.

### Optional: Use VS Code Live Server

1. Install the **Live Server** extension by Ritwick Dey.
2. Right-click `index.html` in VS Code.
3. Select **Open with Live Server**.
4. Open the URL displayed by Live Server, often `http://127.0.0.1:5500`.

### Optional: Run with Python's built-in server

In the VS Code terminal, run:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## How to create a CV

1. Select **New resume** on the dashboard.
2. Enter your name, headline and contact details in the **Personal** tab.
3. Add your real experience, achievements, education, skills, projects and certifications.
4. Choose a resume template and accent color.
5. Use **Writing assistant** to rewrite your own responsibilities more clearly. Check suggestions for accuracy before copying them into your experience section.
6. Open **ATS checker** to review missing sections. Optionally paste a real job description to identify potential keyword gaps.
7. Return to **Resume editor** and click **Save as PDF**. In your browser's print dialog, choose **Save as PDF** and turn off headers/footers for a cleaner document.

You can save different resume versions for different jobs. Each resume is stored automatically in your browser.

## Important: What the ATS score means

The ATS checker is an **educational heuristic**, not an official industry ATS rating. There is no universal ATS score. Actual applicant tracking systems differ in parsing, job criteria and ranking. The tool checks resume completeness and compares literal keywords. It does **not** verify that a CV will pass any employer's system.

Only add keywords and achievements you genuinely possess. Do not invent experience or performance metrics. The writing assistant is a **local template-based editor**, not an AI language model, and does not independently know your work history.

## Project structure

```text
resumecraft-pro/
├── index.html
├── assets/
│   ├── app.js
│   ├── core.js
│   └── styles.css
├── tests/
│   └── core.test.cjs
├── .gitignore
├── LICENSE
└── README.md
```

- `index.html`: Dashboard shell and navigation.
- `assets/styles.css`: Responsive styles, resume layouts and A4 printing rules.
- `assets/core.js`: Reusable model, ATS checklist, keyword comparison, text safety and writing suggestions.
- `assets/app.js`: App views, forms, local persistence, PDF printing and JSON backup/restore.
- `tests/core.test.cjs`: Automated tests for data models and core logic.

## Run the tests (optional)

Node.js 18+ is required **only** to run the tests, not to use ResumeCraft Pro.

```bash
node --test tests/core.test.cjs
```

The suite checks default resume creation, safe HTML escaping, ATS checklist scores, keyword comparison, bullet suggestions and backup model validation.

## Publish on GitHub Pages

1. Create a public repository named `resumecraft-pro` on GitHub.
2. Upload the **extracted** files and folders, keeping `index.html` at the repository root.
3. Open **Settings > Pages**.
4. Choose **Deploy from a branch**, select `main` and `/(root)`, then save.
5. Open the GitHub Pages URL once deployment finishes.

No build step or backend hosting is required.

## Privacy, data and limitations

- Information stays in the browser using Local Storage and is not uploaded to a server by this application.
- Saved CVs do **not** sync across devices or browsers.
- Clearing browser data or using private mode can remove saved CVs. Export regular JSON backups.
- Browser storage is not encrypted. Avoid entering sensitive data on shared computers.
- PDF generation is performed through the browser's **Print > Save as PDF** feature. Results may vary slightly by browser and printer settings.
- The keyword checker is a simple text comparison and does not understand every synonym or role-specific requirement.
- The writing assistant creates polished drafting alternatives but cannot confirm factual accuracy.
- Always review your final PDF for layout and accuracy before applying to jobs.

## Contributing

Contributions are welcome. Fork the repository, create a branch, make and test changes, then open a pull request.

## License

Released under the [MIT License](LICENSE).
