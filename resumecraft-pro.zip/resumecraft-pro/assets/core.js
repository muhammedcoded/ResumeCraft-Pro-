(function(root,factory){const lib=factory();if(typeof module==='object'&&module.exports)module.exports=lib;root.ResumeCore=lib;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const uid=()=>Math.random().toString(36).slice(2,9)+Date.now().toString(36);
const clean=s=>String(s??'').trim();
const defaults=()=>({id:uid(),title:'Untitled Resume',template:'classic',accent:'#2563eb',updatedAt:new Date().toISOString(),personal:{name:'',role:'',email:'',phone:'',location:'',website:'',linkedin:'',summary:''},skills:[],experience:[],education:[],projects:[],certifications:[]});
const newExperience=()=>({id:uid(),role:'',company:'',location:'',start:'',end:'',current:false,bullets:[]});
const newEducation=()=>({id:uid(),degree:'',school:'',location:'',year:'',details:''});
const newProject=()=>({id:uid(),name:'',technology:'',link:'',description:''});
const newCertification=()=>({id:uid(),name:'',issuer:'',year:''});
function escapeHTML(s){return String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));}
function keywords(text){return [...new Set((clean(text).toLowerCase().match(/[a-z][a-z0-9+#.\/-]{2,}/g)||[]).filter(w=>!STOP.has(w)))];}
const STOP=new Set('the and for with from you your our are this that have has will into each using use used who what when where they their his her she was were not can able about including across through team role job experience work working candidate required preferred strong good excellent ability understanding knowledge years year plus skills skill developer engineer development professional position responsible responsibilities demonstrated proven must should maintain build building develop developing support supporting system systems software applications application tools tool'.split(' '));
function analyzeATS(resume,job=''){
 const p=resume.personal||{},ex=resume.experience||[],ed=resume.education||[],sk=resume.skills||[];
 const issues=[],wins=[];
 function item(test,points,title,description){if(test){wins.push(title);return points;}issues.push({title,description});return 0;}
 let score=0;
 score+=item(clean(p.name).length>2&&clean(p.role).length>2,12,'Clear name and headline','Add your full name and a precise professional title.');
 score+=item(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean(p.email)),10,'Valid contact email','Include a valid professional email address.');
 score+=item(clean(p.phone).length>=7&&clean(p.location).length>=3,8,'Phone and location','Include a contact number and location.');
 score+=item(clean(p.summary).length>=70,12,'Professional summary','Write a targeted summary of at least 70 characters.');
 score+=item(sk.filter(x=>clean(x)).length>=5,10,'Relevant skills listed','Add at least five demonstrable, job-relevant skills.');
 score+=item(ex.length>0&&ex.some(x=>clean(x.role)&&clean(x.company)),12,'Work experience structure','Include a role and company in your experience.');
 const bullets=ex.flatMap(x=>x.bullets||[]).filter(clean);
 score+=item(bullets.length>=3,12,'Achievement bullets','Add three or more specific experience bullets.');
 score+=item(bullets.some(x=>/\b\d+(?:[.,]\d+)?\s*(?:%|k|m|hours?|users?|clients?|projects?|requests?|seconds?|days?|weeks?|months?|years?|\$|₦)?\b/i.test(x)),8,'Measurable impact','Add accurate numbers or outcomes wherever possible. Do not invent metrics.');
 score+=item(ed.length>0&&ed.some(x=>clean(x.degree)&&clean(x.school)),8,'Education details','Include a qualification and institution.');
 score+=item(['classic','modern','compact'].includes(resume.template),8,'ATS-friendly template','Select a simple, single-column text-based template.');
 const jobKeys=keywords(job),resumeText=[p.role,p.summary,sk.join(' '),...ex.flatMap(x=>[x.role,x.company,...(x.bullets||[])]),...(resume.projects||[]).map(x=>x.description)].join(' ');
 const body=new Set(keywords(resumeText));const matched=jobKeys.filter(k=>body.has(k)),missing=jobKeys.filter(k=>!body.has(k));
 return {score:Math.min(100,score),issues,wins,job:{matched,missing,coverage:jobKeys.length?Math.round(matched.length/jobKeys.length*100):null,total:jobKeys.length}};
}
const VERBS=['Built','Developed','Improved','Automated','Designed','Implemented','Optimized','Managed','Delivered','Integrated','Tested','Streamlined'];
function suggestBullets({role='',task='',tools='',outcome=''}={}){
 const action=clean(task).replace(/[.!]+$/,'');const tech=clean(tools);const result=clean(outcome).replace(/[.!]+$/,'');
 if(!action)return [];
 const normalized=action.charAt(0).toLowerCase()+action.slice(1);
 const subject=normalized.replace(/^(built|developed|improved|automated|designed|implemented|optimized|managed|delivered|integrated|tested|streamlined|created|worked on|responsible for|handled|helped with)\s+/i,'');
 const toolPhrase=tech?' using '+tech:'';const impact=result?', '+result.charAt(0).toLowerCase()+result.slice(1):'';
 return [
 `${VERBS[0]} ${subject}${toolPhrase}${impact}.`,
 `Implemented ${subject}${tech?' with '+tech:''}${result?', resulting in '+result.charAt(0).toLowerCase()+result.slice(1):''}.`,
 `Improved ${subject}${tech?' through '+tech:''}${result?', with the outcome: '+result.charAt(0).toLowerCase()+result.slice(1):''}.`
 ].map(s=>s.replace(/\s+/g,' ').replace(/\.\./g,'.'));
}
function validateResume(data){return !!data&&typeof data==='object'&&typeof data.id==='string'&&data.personal&&typeof data.personal==='object'&&Array.isArray(data.experience)&&Array.isArray(data.skills)&&Array.isArray(data.education)&&Array.isArray(data.projects)&&Array.isArray(data.certifications);}
function normalizeResume(obj){if(!validateResume(obj))throw new Error('Invalid resume data');const base=defaults();return {...base,...obj,personal:{...base.personal,...obj.personal},skills:obj.skills.slice(0,100).map(x=>clean(x).slice(0,150)),experience:obj.experience.slice(0,70).map(x=>({...newExperience(),...x,bullets:(Array.isArray(x.bullets)?x.bullets:[]).slice(0,50)})),education:obj.education.slice(0,50),projects:obj.projects.slice(0,50),certifications:obj.certifications.slice(0,50)};}
return {uid,clean,defaults,newExperience,newEducation,newProject,newCertification,escapeHTML,keywords,analyzeATS,suggestBullets,validateResume,normalizeResume};
});
